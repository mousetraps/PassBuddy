/* jscrypto library, random number generator
 *   by GUAN Zhi <guanzhi at guanzhi dot org>
 *
 * 
 */

if (typeof(jscrypto) == 'undefined') {jscrypto = {};}
if (typeof(jscrypto.rand) == 'undefined') {jscrypto.rand = {}; }

jscrypto.rand.fortuna = function() {
};

