/* jscrypto library, aes in cbc mode with padding
 *   by GUAN Zhi <guanzhi at guanzhi dot org>
 */

